<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="http://lab.vntu.org/webusers/01-16-041/4k2lab/main.css" type="text/css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

</head>
<body>
		<div class="menu">
		<?php
			session_start();
			echo '<a href="http://lab.vntu.org/webusers/01-16-041/4k2lab/main.php">Головна</a>';
			if(isset($_SESSION['success'])){
    			echo '<a href="http://lab.vntu.org/webusers/01-16-041/4k2lab/users.php">Користувачі</a>';
    			echo '<a href="http://lab.vntu.org/webusers/01-16-041/4k2lab/logout.php">Вихід</a>';
			} else {
				echo '<a href="http://lab.vntu.org/webusers/01-16-041/4k2lab/view/registration.php">Реєстрація</a>';
			}
		?>
		</div>
		
		<h1 style="text-align: center;">Головна</h1>
</body>
</html>
